export default function Projects() {
    return (
        <main className="page-Projects">
            <h2>Projects</h2>

            <div className="content">
                <p>Education</p>
                <p>  Blog Ebooks Guides,
                     More Free Courses,
                     Certifications,
                     Inbound Methodology</p>

                <p>Why HubSpot?</p>
                <p>Case Studies,
                   Why Choose HubSpot?</p>

                <p>Services</p>
                <p>Onboarding,
                   Consulting Services,
                   Hire a Service Provider</p>

                <p>User Resources</p>
                <p>Partner Programs,
                    Developer Tools,
                    Community,
                    HubSpot Ecosystem</p>

            </div>
        </main>
    );
}









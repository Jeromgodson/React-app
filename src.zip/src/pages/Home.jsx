export default function Home() {
    return (
        <main className="page Home">
            <h2>Home</h2>

            <div className="content">
                <p>
                     Serving as your company's virtual front door, this page is responsible for drawing in a majority of your website's traffic. Still, despite its prominence, many businesses struggle to optimize it properly. You see, your homepage needs to wear a lot of hats. Rather than treating it like a <a href="https://blog.hubspot.com/blog/tabid/6307/bid/31097/12-critical-elements-every-homepage-must-have-infographic.aspx">dedicated landing page</a> built around one particular action, it should be designed to serve different audiences, from different origins. And in order to do so effectively, it needs to be built with purpose. In other words, you'll need to incorporate elements that attract traffic, educate visitors, and invite conversions. To improve the performance of your homepage, check out these elements every homepage must have.
                </p>
            </div>
        </main>
    );
}
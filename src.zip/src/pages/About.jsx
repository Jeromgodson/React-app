export default function About() {
    return (
        <main className="page-About">
            <h2>About</h2>

            <div className="content">
                <p>Our Mission</p>
                    <p>There's this notion that to grow a business, you have to be ruthless. But we know there's a better way to grow. One where what's good for the bottom line is also good for customers. We believe businesses can grow with a conscience, and succeed with a soul — and that they can do it with inbound. That's why we've created an ecosystem uniting software, education, and community to help businesses grow better every day.</p>

                <p>Our Story</p>
                    <p>As fellow graduate students at MIT in 2004, Brian and Dharmesh noticed a shift in the way people shop and buy. Consumers were no longer tolerating interruptive bids for their attention — in fact, they'd gotten really, really good at ignoring them. From this shift, a company was born: HubSpot. It was founded on "inbound", the notion that people don't want to be interrupted by marketers or harassed by salespeople — they want to be helped. Today, the inbound movement continues to empower businesses around the world to stop interrupting, start helping, and return their focus to the customer.</p>
            </div>
        </main>
    );
}
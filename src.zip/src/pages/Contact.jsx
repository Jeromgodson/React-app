export default function Contact() {
    return (
        <main className="page-Contact">
            <h2>Contact</h2>

            <div className="content">
                <p>Customer Service Details</p>
                 <p>Tel: 0860 03 04 03,</p>
                 <p>General Queries:  queries@hugetelecom.co.za,</p>
                 <p>Support:  support@hugetelecom.co.za</p>
            </div>
        </main>
    );
}
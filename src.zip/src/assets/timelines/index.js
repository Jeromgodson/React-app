import { Power1, gsap } from 'gsap';


export const play = (pathname, node, appears) => {
    console.log( 'play', pathname, node, appears );

    const delay = appears ? 0 : 0.4;

    //const timeline = new Timeline({ paused: true });
    var tl = gsap.timeline({ paused: true });
    const header = node.querySelector('main h2');
    const content = node.querySelector('main .content');

      
        tl
          .from(node, { duration: 0.2,  display: 'none', autoAlpha: 0, delay, ease: Power1.easeIn })
          .from(header, { duration: 0.15, autoAlpha: 0, y: 20, ease: Power1.easeInOut })
          .from(content, { duration: 0.15, autoAlpha: 0, delay: 0.10, ease: Power1.easeIn });

        tl.play();  
      
}


export const exit = (node) => {
    console.log( 'exit', node, );


    //const timeline = new Timeline({ paused: true });
    var tl = gsap.timeline({ paused: true });

    tl.to(node, { duration: 0.15, autoAlpha: 0, ease: Power1.easeOut });
    tl.play();


}
